import ReactDOM from 'react-dom/client'

import App from './App'

ReactDOM.createRoot(document.getElementById('root')).render(<App />)

import React from 'react';
import ReactDOM from 'react-dom/client';  // For React 18+; use 'react-dom' for older versions
import App from './App';  // Import your main App component

// React 18+ rendering method:
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
