import React, { useState } from 'react';
import AnecdoteList from './AnecdoteList';

const App = () => {
  const anecdotes = [
    'Anecdote 1: This is funny.',
    'Anecdote 2: This is hilarious.',
    'Anecdote 3: This is amusing.'
  ];

  const [votes, setVotes] = useState([0, 0, 0]);

  return (
    <div>
      <h1>Anecdotes</h1>
      <AnecdoteList anecdotes={anecdotes} votes={votes} setVotes={setVotes} />
    </div>
  );
};

export default App;
