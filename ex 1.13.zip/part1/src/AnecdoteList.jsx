import React from 'react';
import VoteButton from './VoteButton';

const AnecdoteList = ({ anecdotes, votes, setVotes }) => {
  const handleVote = (index) => {
    const newVotes = [...votes];
    newVotes[index] += 1;
    setVotes(newVotes);
  };

  return (
    <table>
      <thead>
        <tr>
          <th>Anecdote</th>
          <th>Votes</th>
          <th>Vote</th>
        </tr>
      </thead>
      <tbody>
        {anecdotes.map((anecdote, index) => (
          <tr key={index}>
            <td>{anecdote}</td>
            <td>{votes[index]}</td>
            <td>
              <VoteButton onClick={() => handleVote(index)} />
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default AnecdoteList;
