import React from 'react';

const VoteButton = ({ onClick }) => {
  return <button onClick={onClick}>Vote</button>;
};

export default VoteButton;
