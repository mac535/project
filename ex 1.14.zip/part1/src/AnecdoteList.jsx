
import React from 'react';
import VoteButton from './VoteButton';

const AnecdoteList = ({ anecdotes, votes, handleVote }) => {
  return (
    <table>
      <thead>
        <tr>
          <th>Anecdote</th>
          <th>Votes</th>
          <th>Vote</th>
        </tr>
      </thead>
      <tbody>
        {anecdotes.map((anecdote, index) => (
          <tr key={index}>
            <td>{anecdote}</td>
            <td>{votes[index]}</td>
            <td>
              <VoteButton onClick={() => handleVote(index)} />
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default AnecdoteList;
