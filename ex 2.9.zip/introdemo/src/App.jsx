import { useState } from 'react';

const App = () => {
  // State to store the list of persons (phonebook)
  const [persons, setPersons] = useState([
    { name: 'Arto Hellas', number: '040-123456', id: 1 },
    { name: 'Ada Lovelace', number: '39-44-5323523', id: 2 },
    { name: 'Dan Abramov', number: '12-43-234345', id: 3 },
    { name: 'Mary Poppendieck', number: '39-23-6423122', id: 4 }
  ]);
  
  // State to store the value of the new name and number input fields
  const [newName, setNewName] = useState('');
  const [newNumber, setNewNumber] = useState('');
  
  // State to store the search term
  const [searchTerm, setSearchTerm] = useState('');

  // Handle the form submit action
  const handleAddPerson = (event) => {
    event.preventDefault(); // Prevent page refresh on form submit

    // Check if the name already exists in the phonebook
    const nameExists = persons.some(person => person.name === newName);

    // If name exists, issue an alert and do not add the person
    if (nameExists) {
      alert(`${newName} is already added to phonebook`);
      return; // Prevent further action
    }

    // Add the new name and number to the phonebook
    setPersons([...persons, { name: newName, number: newNumber, id: persons.length + 1 }]);
    setNewName(''); // Clear the name input field after submitting
    setNewNumber(''); // Clear the number input field after submitting
  };

  // Handle changes in the name input field
  const handleNameChange = (event) => {
    setNewName(event.target.value);
  };

  // Handle changes in the number input field
  const handleNumberChange = (event) => {
    setNewNumber(event.target.value);
  };

  // Handle changes in the search input field
  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value.toLowerCase()); // Convert search term to lowercase for case-insensitivity
  };

  // Filter the persons list based on the search term
  const filteredPersons = persons.filter(person =>
    person.name.toLowerCase().includes(searchTerm)
  );

  return (
    <div>
      <h2>Phonebook</h2>

      {/* Search input field */}
      <div>
        <input
          type="text"
          placeholder="Search by name..."
          value={searchTerm}
          onChange={handleSearchChange}
        />
      </div>

      {/* Form to add a new name and number */}
      <form onSubmit={handleAddPerson}>
        <div>
          name: <input
            value={newName} // Bind input field value to newName state
            onChange={handleNameChange} // Handle input change to update newName state
          />
        </div>
        <div>
          number: <input
            value={newNumber} // Bind input field value to newNumber state
            onChange={handleNumberChange} // Handle input change to update newNumber state
          />
        </div>
        <div>
          <button type="submit">add</button>
        </div>
      </form>

      {/* Displaying the filtered list of persons */}
      <h2>Numbers</h2>
      <ul>
        {filteredPersons.map((person) => (
          <li key={person.id}>{person.name} {person.number}</li> // Render each person's name and number in a list
        ))}
      </ul>

      {/* Debugging: Displaying the newName, newNumber, and searchTerm states */}
      <div>debug: {newName} | {newNumber} | {searchTerm}</div>
    </div>
  );
};

export default App;
