const Filter = ({ searchTerm, handleSearchChange }) => {
  return (
    <div>
      <input
        type="text"
        placeholder="Search by name..."
        value={searchTerm}
        onChange={handleSearchChange}
      />
    </div>
  );
};

export default Filter;