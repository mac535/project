import React from 'react';

// Header Component
const Header = ({ courseName }) => {
  return <h1>{courseName}</h1>;
};

// Part Component
const Part = ({ part }) => {
  return <p>{part.name} {part.exercises}</p>;
};

// Content Component
const Content = ({ parts }) => {
  return (
    <div>
      {parts.map(part => (
        <Part key={part.id} part={part} />
      ))}
    </div>
  );
};

// Course Component
const Course = ({ course }) => {
  // Calculate the sum of exercises
  const totalExercises = course.parts.reduce((sum, part) => sum + part.exercises, 0);

  return (
    <div>
      <Header courseName={course.name} />
      <Content parts={course.parts} />
      <p><strong>Total exercises: {totalExercises}</strong></p>
    </div>
  );
}

export default Course;
