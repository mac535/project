import { useState } from 'react';

const App = () => {
  const [persons, setPersons] = useState([
    { name: 'Arto Hellas' }
  ]);
  const [newName, setNewName] = useState('');

  // Handle the form submit action
  const handleAddPerson = (event) => {
    event.preventDefault(); // Prevent page refresh on form submit

    // Check if the name already exists in the phonebook
    const nameExists = persons.some(person => person.name === newName);

    // If name exists, issue an alert and do not add the person
    if (nameExists) {
      alert(`${newName} is already added to phonebook`);
      return; // Prevent further action
    }

    // Add the new name to the phonebook
    setPersons([...persons, { name: newName }]);
    setNewName(''); // Clear the input field after submitting
  };

  // Handle changes in the input field (updating the newName state)
  const handleInputChange = (event) => {
    setNewName(event.target.value);
  };

  return (
    <div>
      <h2>Phonebook</h2>

      {/* Form to add a new name */}
      <form onSubmit={handleAddPerson}>
        <div>
          name: <input
            value={newName} // Bind input field value to newName state
            onChange={handleInputChange} // Handle input change to update newName state
          />
        </div>
        <div>
          <button type="submit">add</button>
        </div>
      </form>

      {/* Displaying the current state of the phonebook */}
      <h2>Numbers</h2>
      <ul>
        {persons.map((person, index) => (
          <li key={index}>{person.name}</li> // Render each person's name in a list
        ))}
      </ul>

      {/* Debugging: Displaying the newName state */}
      <div>debug: {newName}</div>
    </div>
  );
};

export default App;
