import { useState } from 'react';

const App = () => {
  // State to store the list of persons with names and phone numbers
  const [persons, setPersons] = useState([
    { name: 'Arto Hellas', number: '040-1234567' }
  ]);
  
  // State to store the value of the new name and number input fields
  const [newName, setNewName] = useState('');
  const [newNumber, setNewNumber] = useState('');

  // Handle the form submit action
  const handleAddPerson = (event) => {
    event.preventDefault(); // Prevent page refresh on form submit

    // Check if the name already exists in the phonebook
    const nameExists = persons.some(person => person.name === newName);

    // If name exists, issue an alert and do not add the person
    if (nameExists) {
      alert(`${newName} is already added to phonebook`);
      return; // Prevent further action
    }

    // Add the new name and number to the phonebook
    setPersons([...persons, { name: newName, number: newNumber }]);
    setNewName(''); // Clear the name input field after submitting
    setNewNumber(''); // Clear the number input field after submitting
  };

  // Handle changes in the name input field
  const handleNameChange = (event) => {
    setNewName(event.target.value);
  };

  // Handle changes in the number input field
  const handleNumberChange = (event) => {
    setNewNumber(event.target.value);
  };

  return (
    <div>
      <h2>Phonebook</h2>

      {/* Form to add a new name and number */}
      <form onSubmit={handleAddPerson}>
        <div>
          name: <input
            value={newName} // Bind input field value to newName state
            onChange={handleNameChange} // Handle input change to update newName state
          />
        </div>
        <div>
          number: <input
            value={newNumber} // Bind input field value to newNumber state
            onChange={handleNumberChange} // Handle input change to update newNumber state
          />
        </div>
        <div>
          <button type="submit">add</button>
        </div>
      </form>

      {/* Displaying the current state of the phonebook */}
      <h2>Numbers</h2>
      <ul>
        {persons.map((person, index) => (
          <li key={index}>{person.name} {person.number}</li> // Render each person's name and number in a list
        ))}
      </ul>

      {/* Debugging: Displaying the newName and newNumber state */}
      <div>debug: {newName} | {newNumber}</div>
    </div>
  );
};

export default App;
